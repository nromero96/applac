<?php return array (
  'dashboard-report-performance' => 'App\\Http\\Livewire\\DashboardReportPerformance',
  'new-inquiry' => 'App\\Http\\Livewire\\NewInquiry',
  'organization-form' => 'App\\Http\\Livewire\\OrganizationForm',
  'organizations-list' => 'App\\Http\\Livewire\\OrganizationsList',
);